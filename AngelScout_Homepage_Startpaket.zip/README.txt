ANGELSCOUT – HOMEPAGE

1. Öffne index.html, um die Homepage lokal anzusehen.
2. Öffne script.js und ersetze:
   DEINE-EMAIL@HIER-EINTRAGEN.DE
   durch deine echte Geschäfts-E-Mail-Adresse.
3. Fülle impressum.html und datenschutz.html mit deinen echten Angaben.
4. Vor dem Livegang: Gewerbe, Versicherungen, Datenschutz, Zahlungsabwicklung,
   rechtliche Anforderungen für Angelguiding/Gewässerrecherche und ggf. Fischverkauf
   individuell prüfen.
5. Für echte Online-Zahlungen (z.B. Kartenzahlung/PayPal) und automatische Buchungen
   brauchst du später einen Zahlungs-/Buchungsanbieter oder ein Backend.
6. Für einen professionellen Start kannst du diese Dateien bei einem Webhoster
   hochladen. Die Seite ist mobiloptimiert und benötigt keine externe Bibliothek.

DATEIEN
- index.html        Hauptseite
- style.css         Design
- script.js         Formular/Interaktion
- impressum.html    Platzhalter für Impressum
- datenschutz.html  Platzhalter für Datenschutz

Die Preise und Leistungen entsprechen dem bisherigen Konzept:
BASIC 19,90 €
PRO 39,90 €
PREMIUM 69,90 €
ANGELGUIDE ab 99 €
