const DESTINATION_EMAIL = "DEINE-EMAIL@HIER-EINTRAGEN.DE";

const menu = document.querySelector(".menu-toggle");
const links = document.querySelector(".nav-links");
if (menu) menu.addEventListener("click", () => links.classList.toggle("open"));

document.querySelectorAll(".nav-links a").forEach(a => a.addEventListener("click", () => links.classList.remove("open")));

const form = document.getElementById("leadForm");
const success = document.getElementById("success");

form.addEventListener("submit", (event) => {
  event.preventDefault();
  const data = new FormData(form);
  const subject = `AngelScout Anfrage – ${data.get("fish")}`;
  const body =
`Neue AngelScout Anfrage

Name: ${data.get("name")}
E-Mail: ${data.get("email")}
Zielfisch: ${data.get("fish")}
Angelart: ${data.get("method")}
Max. Entfernung: ${data.get("distance")}
Paket: ${data.get("package")}
Zeitraum: ${data.get("date")}

Was wird gesucht:
${data.get("message")}`;

  if (DESTINATION_EMAIL.includes("DEINE-EMAIL")) {
    alert("Bitte trage zuerst deine echte E-Mail-Adresse in script.js ein.");
    return;
  }

  window.location.href = `mailto:${DESTINATION_EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  success.hidden = false;
});
